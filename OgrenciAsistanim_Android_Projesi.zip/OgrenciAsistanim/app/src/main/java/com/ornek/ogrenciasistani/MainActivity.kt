package com.ornek.ogrenciasistani

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("student_data", MODE_PRIVATE) }
    private val students = mutableListOf<Student>()
    private val tasks = mutableListOf<StudyTask>()
    private var selectedStudentId = ""
    private lateinit var root: LinearLayout
    private lateinit var studentSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadData()
        if (students.isEmpty()) {
            students.add(Student("s1", "Örnek Öğrenci", "9. Sınıf"))
            selectedStudentId = "s1"
            saveData()
        }
        if (selectedStudentId.isBlank()) selectedStudentId = students.first().id
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
        render()
    }

    private fun loadData() {
        try {
            val s = JSONArray(prefs.getString("students", "[]"))
            for (i in 0 until s.length()) {
                val o = s.getJSONObject(i); students.add(Student(o.getString("id"), o.getString("name"), o.optString("grade", "")))
            }
            val t = JSONArray(prefs.getString("tasks", "[]"))
            for (i in 0 until t.length()) {
                val o = t.getJSONObject(i); tasks.add(StudyTask(o.getString("id"), o.getString("studentId"), o.getString("title"), o.getString("time"), o.optString("date", today()), o.optBoolean("done", false)))
            }
            selectedStudentId = prefs.getString("selected", "") ?: ""
        } catch (_: Exception) { }
    }

    private fun saveData() {
        val s = JSONArray(); students.forEach { s.put(JSONObject().put("id", it.id).put("name", it.name).put("grade", it.grade)) }
        val t = JSONArray(); tasks.forEach { t.put(JSONObject().put("id", it.id).put("studentId", it.studentId).put("title", it.title).put("time", it.time).put("date", it.date).put("done", it.done)) }
        prefs.edit().putString("students", s.toString()).putString("tasks", t.toString()).putString("selected", selectedStudentId).apply()
    }

    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 16f, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(0xFF202633.toInt()); if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(dp(2), dp(5), dp(2), dp(5))
    }
    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }
    private fun field(hintText: String) = EditText(this).apply { hint = hintText; textSize = 16f; singleLine = true; setPadding(dp(12), dp(8), dp(12), dp(8)) }

    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); setBackgroundColor(0xFFF7F8FC.toInt()) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, -1))
        content.addView(text("ÖĞRENCİ ASİSTANIM", 22f, true))
        content.addView(text("Öğrenci takibi • Günlük plan • Hatırlatıcı", 13f))
        content.addView(text("Öğrenci seç", 17f, true))
        studentSpinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, students.map { "${it.name} (${it.grade})" })
        studentSpinner.adapter = adapter
        val idx = students.indexOfFirst { it.id == selectedStudentId }.coerceAtLeast(0)
        studentSpinner.setSelection(idx)
        studentSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position in students.indices && selectedStudentId != students[position].id) { selectedStudentId = students[position].id; saveData(); render() }
            }
        }
        content.addView(studentSpinner)

        content.addView(text("Yeni öğrenci ekle", 17f, true))
        val studentName = field("Adı soyadı")
        val grade = field("Sınıfı (ör. 8. Sınıf)")
        content.addView(studentName); content.addView(grade)
        content.addView(button("+ Öğrenci ekle") {
            val n = studentName.text.toString().trim(); val g = grade.text.toString().trim()
            if (n.isBlank()) { toast("Öğrenci adını yazın") } else {
                val st = Student(System.currentTimeMillis().toString(), n, g.ifBlank { "Belirtilmedi" }); students.add(st); selectedStudentId = st.id; saveData(); render()
            }
        })

        val mine = tasks.filter { it.studentId == selectedStudentId && it.date == today() }
        val completed = mine.count { it.done }
        content.addView(text("Bugünün özeti", 18f, true))
        content.addView(text("${mine.size} görev • $completed tamamlandı • ${mine.size - completed} bekliyor", 15f))
        content.addView(text("Günlük plana görev ekle", 17f, true))
        val taskTitle = field("Örn. Matematik 20 soru çöz")
        val taskTime = field("Saat (24 saat biçimi: 18:30)").apply { setText("18:00") }
        content.addView(taskTitle); content.addView(taskTime)
        content.addView(button("+ Görevi kaydet ve hatırlatıcı kur") {
            val title = taskTitle.text.toString().trim(); val time = taskTime.text.toString().trim()
            if (title.isBlank()) { toast("Görev adını yazın") }
            else if (!time.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d"))) { toast("Saati 18:30 biçiminde girin") }
            else {
                val item = StudyTask(System.currentTimeMillis().toString(), selectedStudentId, title, time, today(), false)
                tasks.add(item); scheduleReminder(item); saveData(); render(); toast("Görev kaydedildi")
            }
        })
        content.addView(text("Bugünkü görevler", 18f, true))
        if (mine.isEmpty()) content.addView(text("Bugün için henüz görev yok."))
        mine.sortedBy { it.time }.forEach { task ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(5)) }
            val cb = CheckBox(this).apply { isChecked = task.done; setOnCheckedChangeListener { _, checked -> task.done = checked; saveData(); render() } }
            val label = TextView(this).apply { text = "${task.time}  ${task.title}"; textSize = 15f; setTextColor(0xFF202633.toInt()); setPadding(dp(4), dp(4), dp(4), dp(4)); if (task.done) paintFlags = paintFlags or 0x10 }
            line.addView(cb); line.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            line.addView(Button(this).apply { text = "Sil"; setOnClickListener { tasks.removeAll { it.id == task.id }; cancelReminder(task); saveData(); render() } })
            content.addView(line)
        }
        content.addView(text("Hatırlatma notu", 16f, true))
        content.addView(text("Bildirimlerin gelmesi için uygulama bildirim iznini açık tutun. Android pil tasarrufu bazı cihazlarda bildirimleri geciktirebilir.", 13f))
        setContentView(root)
    }

    private fun scheduleReminder(task: StudyTask) {
        val parts = task.time.split(":")
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, parts[0].toInt()); set(Calendar.MINUTE, parts[1].toInt()); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("title", task.title).putExtra("student", students.find { it.id == task.studentId }?.name ?: "Öğrenci")
        val pi = PendingIntent.getBroadcast(this, task.id.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi) else alarm.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }

    private fun cancelReminder(task: StudyTask) {
        val pi = PendingIntent.getBroadcast(this, task.id.hashCode(), Intent(this, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pi != null) (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
    }
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

data class Student(val id: String, val name: String, val grade: String)
data class StudyTask(val id: String, val studentId: String, val title: String, val time: String, val date: String, var done: Boolean)
