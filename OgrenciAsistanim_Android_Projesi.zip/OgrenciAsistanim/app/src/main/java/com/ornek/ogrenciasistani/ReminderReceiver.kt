package com.ornek.ogrenciasistani

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "study_reminders"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(NotificationChannel(channelId, "Ders hatırlatıcıları", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val title = intent.getStringExtra("title") ?: "Ders çalışma zamanı"
        val student = intent.getStringExtra("student") ?: "Öğrenci"
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.app.Notification.Builder(context, channelId).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Ders hatırlatıcısı").setContentText("$student: $title").setAutoCancel(true).build()
        } else {
            @Suppress("DEPRECATION")
            android.app.Notification.Builder(context).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Ders hatırlatıcısı").setContentText("$student: $title").setAutoCancel(true).build()
        }
        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
