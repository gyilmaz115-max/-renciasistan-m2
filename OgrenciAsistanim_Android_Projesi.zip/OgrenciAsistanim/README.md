# Öğrenci Asistanım (Android)

Basit, çok öğrencili öğrenci takip uygulaması.

## Özellikler
- Birden fazla öğrenci ekleme ve öğrenci seçme
- Sınıf bilgisi kaydetme
- Günlük görev ekleme ve saat belirleme
- Android bildirim hatırlatıcısı kurma
- Görevleri tamamlandı olarak işaretleme veya silme
- Öğrenci ve görev verilerini telefonda SharedPreferences ile saklama

## APK oluşturma
Bu klasörü Android Studio'da **Open** ile açın. Android SDK 35 ve JDK 17 yüklü olmalı. Gradle eşitlemesi tamamlandıktan sonra:

**Build > Build Bundle(s) / APK(s) > Build APK(s)**

APK yolu: `app/build/outputs/apk/debug/app-debug.apk`

İlk açılışta bildirim izni istenir. Hatırlatıcı saatleri telefonun yerel saatine göre ayarlanır. Uygulama açık olmasa da alarm bildirimi çalışır; Android üretici pil kısıtlamaları gecikmeye neden olabilir.
